function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bZN4acmsTg":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

